const express = require('express')

const router = express.Router()
router.get("/", (req, res) => {
    res.send('Users List')
})

router.get("/new", (req, res) => {
    res.send("New User")
})

router.post("/create", (req, res) => {
    res.send("User Created")
})

module.exports = router

router.get("/:id", (req, res) => {
    res.send(`User with ID: ${req.params.id}`)
})